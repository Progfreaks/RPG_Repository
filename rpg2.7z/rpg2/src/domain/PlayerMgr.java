package domain;
import domain.DuD;
import valueobject.fieldobjects.TestFigure;
public class PlayerMgr {

}
