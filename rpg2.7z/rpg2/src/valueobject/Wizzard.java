package valueobject;

public class Wizzard {

}
