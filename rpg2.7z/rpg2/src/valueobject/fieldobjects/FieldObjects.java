package valueobject.fieldobjects;

public abstract class FieldObjects {
	
	public abstract int getXCoord();
		
	public abstract int getYCoord();
	
	public abstract FieldObjects getFieldObject();

}
