package valueobject.events;

public abstract class GameEvent {

	public abstract void process();
	
}
